package com.example.myapplication

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.example.myapplication.databinding.ActivityHubDetailScreenBinding

class Hub_detail_screen : AppCompatActivity() {
    private lateinit var binding: ActivityHubDetailScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHubDetailScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Récupérer les données du hub depuis l'intent
        val hubId = intent.getStringExtra("HUB_ID")
        val hubName = intent.getStringExtra("HUB_NAME")
        val hubDescription = intent.getStringExtra("HUB_DESCRIPTION")
        val hubProfileImageUrl = intent.getStringExtra("HUB_PROFILE_IMAGE_URL")
        val hubCoverImageUrl = intent.getStringExtra("HUB_COVER_IMAGE_URL")
        val hubCreationDate = intent.getStringExtra("HUB_CREATION_DATE")
        val userId = intent.getStringExtra("USER_ID")  // Retrieve userId here

        Toast.makeText(this, userId, Toast.LENGTH_SHORT).show()

        // Afficher les données du hub
        binding.usernameTextView.text = hubName
        binding.description.text = hubDescription
        binding.since.text = hubCreationDate
        Glide.with(this).load(hubProfileImageUrl).into(binding.imageProfile)
        Glide.with(this).load(hubCoverImageUrl).into(binding.imageCouverture)
    }
}