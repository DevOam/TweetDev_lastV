package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.myapplication.model.User
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class ProfilesOfPostOwner : AppCompatActivity() {

    private lateinit var usernameTextView: TextView
    private lateinit var followersCountTextView: TextView
    private lateinit var joinDtae: TextView
    private lateinit var img_profile: ImageView
    private lateinit var image_couverture: ImageView
    private var userId: String? = null
    private var username: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profiles_of_post_owner)

        // Initialize the TextViews
        usernameTextView = findViewById(R.id.usernameTextView)
        followersCountTextView = findViewById(R.id.nbr_folowers)
        joinDtae = findViewById(R.id.since)
        img_profile = findViewById(R.id.image_profile)
        image_couverture = findViewById(R.id.image_couverture)

        username = intent.getStringExtra("username")

        Toast.makeText(this, username, Toast.LENGTH_SHORT).show()

        if (username != null) {
            fetchUserIdByUsername(username!!)
        }

    }

    private fun fetchUserIdByUsername(username: String) {
        val db = FirebaseFirestore.getInstance()
        db.collection("users")
            .whereEqualTo("username", username)
            .get()
            .addOnSuccessListener { result ->
                if (result.isEmpty) {
                    Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show()
                } else {
                    val document = result.documents.first()
                    val userId = document.getString("_id")
                    // Do something with the userId
                    getUserData(userId.toString())
                    Toast.makeText(this, "User ID: $userId", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { exception ->
                Log.w("ProfilesOfPostOwner", "Error getting user ID: ", exception)
                Toast.makeText(this, "Error fetching user ID", Toast.LENGTH_SHORT).show()
            }
    }

    private fun getUserData(userId: String) {
        val db = FirebaseFirestore.getInstance()
        db.collection("users")
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    val user = document.toObject(User::class.java)
                    if (user?._id == userId) {
                        // Utilisateur trouvé
                        usernameTextView.text = user.username
                        followersCountTextView.text = user.followers.size.toString()
                        joinDtae.text = formatJoinDate(user.joinDate)
                        Glide.with(this)
                            .load(user.profileImageUrl)
                            .into(img_profile)
                        Glide.with(this)
                            .load(user.profileImageUrl)
                            .into(image_couverture)
                        break // Sortir de la boucle une fois l'utilisateur trouvé
                    }
                }
            }
            .addOnFailureListener { exception ->
                Log.d("ProfileActivity", "Get failed with ", exception)
            }
    }

    fun formatJoinDate(dateString: String): String {
        val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX", Locale.getDefault())
        val date = inputFormat.parse(dateString)

        val calendar = Calendar.getInstance()
        date?.let {
            calendar.time = it
        }

        val month = calendar.get(Calendar.MONTH) + 1 // Calendar.MONTH is zero-based
        val year = calendar.get(Calendar.YEAR)

        val monthName = getFrenchMonthName(month)

        return "$monthName $year"
    }

    fun getFrenchMonthName(month: Int): String {
        return when (month) {
            1 -> "janvier"
            2 -> "février"
            3 -> "mars"
            4 -> "avril"
            5 -> "mai"
            6 -> "juin"
            7 -> "juillet"
            8 -> "août"
            9 -> "septembre"
            10 -> "octobre"
            11 -> "novembre"
            12 -> "décembre"
            else -> ""
        }
    }

}